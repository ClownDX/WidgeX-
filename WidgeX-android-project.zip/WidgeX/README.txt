WidgeX - Android Studio project
1. Install Android Studio (Koala or newer) and open this folder.
2. Let Gradle sync (needs internet the first time).
3. Build > Build Bundle(s) / APK(s) > Build APK(s), or press Run with a phone connected.
The app shows the WidgeX studio (app/src/main/assets/index.html) inside a WebView.
Your saved widgets stay on the phone. Google Fonts load over the internet.
